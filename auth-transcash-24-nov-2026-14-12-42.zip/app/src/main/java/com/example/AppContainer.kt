package com.example

import android.content.Context
import com.example.data.LocalPreferencesRepository
import com.example.data.SupabaseTicketRepository
import com.example.data.TicketOcrExtractor

class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val supabaseRepository: SupabaseTicketRepository by lazy { SupabaseTicketRepository() }
    val localPreferences: LocalPreferencesRepository by lazy {
        LocalPreferencesRepository(appContext)
    }
    val ocrExtractor: TicketOcrExtractor by lazy { TicketOcrExtractor(appContext) }
}
