package com.example.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

enum class TicketStatus(val apiValue: String, val labelFr: String) {
    PENDING("En attente", "En attente"),
    AUTHENTICATED("Authentifié", "Authentifié"),
    REFUSED("Refusé", "Refusé");

    companion object {
        fun fromApiValue(value: String?): TicketStatus {
            return entries.firstOrNull {
                it.apiValue.equals(value?.trim(), ignoreCase = true)
            } ?: PENDING
        }
    }
}

@Serializable
data class TicketRecord(
    val id: String = "",
    @SerialName("reference_number")
    val referenceNumber: String = "",
    @SerialName("full_name")
    val fullName: String = "",
    @SerialName("phone_number")
    val phoneNumber: String = "",
    @SerialName("photo_path")
    val photoPath: String = "",
    @SerialName("photo_url")
    val photoUrl: String = "",
    @SerialName("extracted_code")
    val extractedCode: String? = null,
    @SerialName("ticket_datetime")
    val ticketDatetime: String? = null,
    val status: String = TicketStatus.PENDING.apiValue,
    @SerialName("admin_note")
    val adminNote: String? = null,
    @SerialName("received_at")
    val receivedAt: String = "",
    @SerialName("validated_at")
    val validatedAt: String? = null
) {
    val ticketStatus: TicketStatus
        get() = TicketStatus.fromApiValue(status)
}

@Serializable
data class TicketInsertPayload(
    @SerialName("reference_number")
    val referenceNumber: String,
    @SerialName("full_name")
    val fullName: String,
    @SerialName("phone_number")
    val phoneNumber: String,
    @SerialName("photo_path")
    val photoPath: String,
    @SerialName("photo_url")
    val photoUrl: String,
    @SerialName("extracted_code")
    val extractedCode: String?,
    @SerialName("ticket_datetime")
    val ticketDatetime: String?,
    val status: String,
    @SerialName("received_at")
    val receivedAt: String
)

@Serializable
data class TicketUpdatePayload(
    val status: String,
    @SerialName("extracted_code")
    val extractedCode: String?,
    @SerialName("ticket_datetime")
    val ticketDatetime: String?,
    @SerialName("admin_note")
    val adminNote: String?,
    @SerialName("validated_at")
    val validatedAt: String?
)

@Serializable
data class SupabaseAuthRequest(
    val email: String,
    val password: String
)

@Serializable
data class SupabaseAuthUser(
    val id: String = "",
    val email: String? = null
)

@Serializable
data class SupabaseAuthResponse(
    @SerialName("access_token")
    val accessToken: String = "",
    @SerialName("refresh_token")
    val refreshToken: String = "",
    val user: SupabaseAuthUser? = null
)

data class OcrExtractionResult(
    val extractedCode: String? = null,
    val ticketDateTime: String? = null,
    val rawText: String = ""
)

data class AdminSession(
    val accessToken: String,
    val email: String
)
