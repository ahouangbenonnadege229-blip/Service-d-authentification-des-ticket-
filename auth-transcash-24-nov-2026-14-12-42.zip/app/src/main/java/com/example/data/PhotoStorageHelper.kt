package com.example.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object PhotoStorageHelper {

    fun createCameraImageUri(context: Context): Uri {
        val ticketsDir = File(context.cacheDir, "tickets").apply { mkdirs() }
        val photoFile = File(ticketsDir, "ticket_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            photoFile
        )
    }

    suspend fun readAndCompressJpeg(context: Context, uri: Uri): ByteArray =
        withContext(Dispatchers.IO) {
            val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Impossible de lire le fichier image sélectionné.")

            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, boundsOptions)

            val maxDim = 1600
            var sampleSize = 1
            while (
                boundsOptions.outWidth / sampleSize > maxDim * 2 ||
                boundsOptions.outHeight / sampleSize > maxDim * 2
            ) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOptions)
                ?: throw IllegalStateException("Format d'image invalide.")

            val rotation = readExifRotation(rawBytes)
            val rotated = if (rotation != 0f) {
                val matrix = Matrix().apply { postRotate(rotation) }
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                    .also { if (it != decoded) decoded.recycle() }
            } else {
                decoded
            }

            val finalBitmap = scaleDownIfNeeded(rotated, maxDim)
            val out = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 86, out)
            if (finalBitmap != rotated) rotated.recycle()
            finalBitmap.recycle()
            out.toByteArray()
        }

    private fun readExifRotation(bytes: ByteArray): Float {
        return runCatching {
            bytes.inputStream().use { stream ->
                val exif = ExifInterface(stream)
                when (
                    exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                ) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }
        }.getOrDefault(0f)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDim && height <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / width, maxDim.toFloat() / height)
        val targetW = (width * ratio).toInt().coerceAtLeast(1)
        val targetH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    suspend fun saveImageToDevice(
        context: Context,
        bytes: ByteArray,
        displayName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val safeName = displayName.replace(Regex("""[^A-Za-z0-9_\-.]"""), "_")
        val fileName = if (safeName.endsWith(".jpg", ignoreCase = true)) safeName else "$safeName.jpg"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_PICTURES}/AuthTranscash"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val itemUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext false

            return@withContext runCatching {
                resolver.openOutputStream(itemUri)?.use { it.write(bytes) }
                    ?: error("OutputStream null")
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                true
            }.getOrElse {
                resolver.delete(itemUri, null, null)
                false
            }
        } else {
            return@withContext runCatching {
                val picturesDir =
                    context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                val targetDir = File(picturesDir, "AuthTranscash").apply { mkdirs() }
                val outFile = File(targetDir, fileName)
                FileOutputStream(outFile).use { it.write(bytes) }
                true
            }.getOrDefault(false)
        }
    }
}
