package com.example.data

import android.content.Context
import android.net.Uri
import com.example.model.OcrExtractionResult
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

class TicketOcrExtractor(private val context: Context) {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun extractFromUri(uri: Uri): OcrExtractionResult = withContext(Dispatchers.Default) {
        val image = runCatching { InputImage.fromFilePath(context, uri) }.getOrNull()
            ?: return@withContext OcrExtractionResult()

        val recognizedText = suspendCancellableCoroutine<String?> { continuation ->
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (continuation.isActive) {
                        continuation.resume(visionText.text)
                    }
                }
                .addOnFailureListener {
                    if (continuation.isActive) {
                        continuation.resume(null)
                    }
                }
        } ?: return@withContext OcrExtractionResult()

        parseTranscashText(recognizedText)
    }

    companion object {
        fun parseTranscashText(rawText: String): OcrExtractionResult {
            val lines = rawText.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            val extractedCode = findBestVoucherCode(lines)
            val ticketDateTime = findDateTime(lines)

            return OcrExtractionResult(
                extractedCode = extractedCode,
                ticketDateTime = ticketDateTime,
                rawText = rawText
            )
        }

        private fun findBestVoucherCode(lines: List<String>): String? {
            val groupedCodeRegex = Regex("""(?<!\d)(?:\d{4}[\s\-]?){3,4}(?!\d)""")
            val continuousDigitsRegex = Regex("""(?<!\d)\d{12,16}(?!\d)""")
            val alphaNumVoucherRegex = Regex("""\b[A-Z0-9]{4}(?:[\s\-][A-Z0-9]{4}){2,3}\b""")

            val prioritizedLines = lines.sortedByDescending { line ->
                val upper = line.uppercase()
                when {
                    upper.contains("CODE") || upper.contains("PIN") -> 3
                    upper.contains("TRANSCASH") || upper.contains("RECHARGE") -> 2
                    else -> 0
                }
            }

            for (line in prioritizedLines) {
                groupedCodeRegex.find(line)?.let { match ->
                    val digitsOnly = match.value.replace(Regex("""[\s\-]"""), "")
                    if (digitsOnly.length in 12..16) {
                        return digitsOnly.chunked(4).joinToString(" ")
                    }
                }
                continuousDigitsRegex.find(line)?.let { match ->
                    if (match.value.length in 12..16) {
                        return match.value.chunked(4).joinToString(" ")
                    }
                }
                alphaNumVoucherRegex.find(line.uppercase())?.let { match ->
                    val cleaned = match.value.replace(Regex("""[\s\-]"""), "")
                    if (cleaned.any { it.isDigit() } && cleaned.length in 12..16) {
                        return cleaned.chunked(4).joinToString(" ")
                    }
                }
            }
            return null
        }

        private fun findDateTime(lines: List<String>): String? {
            val dateRegex =
                Regex("""\b(\d{2}[/\-.]\d{2}[/\-.]\d{2,4}|\d{4}[/\-.]\d{2}[/\-.]\d{2})\b""")
            val timeRegex = Regex("""\b(\d{2}[:hH]\d{2}(?::\d{2})?)\b""")

            var foundDate: String? = null
            var foundTime: String? = null

            for (line in lines) {
                val d = dateRegex.find(line)?.value
                val t = timeRegex.find(line)?.value?.replace('h', ':')?.replace('H', ':')
                if (d != null && t != null) {
                    return "$d $t"
                }
                if (foundDate == null && d != null) foundDate = d
                if (foundTime == null && t != null) foundTime = t
            }

            return when {
                foundDate != null && foundTime != null -> "$foundDate $foundTime"
                foundDate != null -> foundDate
                else -> null
            }
        }
    }
}
