package com.example.data

import com.example.BuildConfig

object SupabaseConfig {
    val baseUrl: String
        get() = BuildConfig.SUPABASE_URL.trim().trimEnd('/')

    val anonKey: String
        get() = BuildConfig.SUPABASE_ANON_KEY.trim()

    val isConfigured: Boolean
        get() = baseUrl.startsWith("https://") &&
            !baseUrl.contains("YOUR_SUPABASE", ignoreCase = true) &&
            anonKey.isNotBlank() &&
            !anonKey.contains("YOUR_SUPABASE", ignoreCase = true)

    const val STORAGE_BUCKET = "ticket-photos"
    const val TICKETS_TABLE = "tickets"
}
