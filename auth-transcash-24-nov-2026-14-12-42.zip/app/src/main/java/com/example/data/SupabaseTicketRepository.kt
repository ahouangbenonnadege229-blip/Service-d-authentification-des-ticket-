package com.example.data

import com.example.model.AdminSession
import com.example.model.SupabaseAuthRequest
import com.example.model.SupabaseAuthResponse
import com.example.model.TicketInsertPayload
import com.example.model.TicketRecord
import com.example.model.TicketStatus
import com.example.model.TicketUpdatePayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.io.IOException
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

class SupabaseTicketRepository {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val httpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(35, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val jpegMediaType = "image/jpeg".toMediaType()
    private val random = SecureRandom()

    fun isConfigured(): Boolean = SupabaseConfig.isConfigured

    fun generateReferenceNumber(): String {
        val dateStamp = DateTimeFormatterUtil.currentCompactDate()
        val suffix = (1000 + random.nextInt(9000))
        return "TC-$dateStamp-$suffix"
    }

    suspend fun submitTicket(
        fullName: String,
        phoneNumber: String,
        jpegBytes: ByteArray,
        extractedCode: String?,
        ticketDateTime: String?
    ): Result<TicketRecord> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext Result.failure(
                IllegalStateException(
                    "Supabase n'est pas configuré. Veuillez renseigner SUPABASE_URL et SUPABASE_ANON_KEY dans le panneau Secrets d'AI Studio."
                )
            )
        }

        runCatching {
            val referenceNumber = generateReferenceNumber()
            val receivedAt = DateTimeFormatterUtil.currentIsoUtc()
            val objectPath = "tickets/${referenceNumber}_${System.currentTimeMillis()}.jpg"

            uploadPhotoToStorage(objectPath, jpegBytes)
            val photoUrl = buildPublicStorageUrl(objectPath)

            val payload = TicketInsertPayload(
                referenceNumber = referenceNumber,
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                photoPath = objectPath,
                photoUrl = photoUrl,
                extractedCode = extractedCode?.takeIf { it.isNotBlank() },
                ticketDatetime = ticketDateTime?.takeIf { it.isNotBlank() },
                status = TicketStatus.PENDING.apiValue,
                receivedAt = receivedAt
            )

            val endpoint = "${SupabaseConfig.baseUrl}/rest/v1/${SupabaseConfig.TICKETS_TABLE}"
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", SupabaseConfig.anonKey)
                .addHeader("Authorization", "Bearer ${SupabaseConfig.anonKey}")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .post(json.encodeToString(payload).toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException(parseSupabaseError(response.code, bodyString))
                }
                val records = json.decodeFromString<List<TicketRecord>>(bodyString)
                records.firstOrNull()
                    ?: throw IOException("Réponse vide du serveur Supabase lors de l'enregistrement.")
            }
        }
    }

    private fun uploadPhotoToStorage(objectPath: String, jpegBytes: ByteArray) {
        val uploadUrl =
            "${SupabaseConfig.baseUrl}/storage/v1/object/${SupabaseConfig.STORAGE_BUCKET}/$objectPath"
        val request = Request.Builder()
            .url(uploadUrl)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Authorization", "Bearer ${SupabaseConfig.anonKey}")
            .addHeader("Content-Type", "image/jpeg")
            .addHeader("x-upsert", "true")
            .post(jpegBytes.toRequestBody(jpegMediaType))
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException(
                    "Échec de l'envoi de la photo vers Supabase Storage (${response.code}) : ${parseSupabaseError(response.code, bodyString)}"
                )
            }
        }
    }

    private fun buildPublicStorageUrl(objectPath: String): String {
        return "${SupabaseConfig.baseUrl}/storage/v1/object/public/${SupabaseConfig.STORAGE_BUCKET}/$objectPath"
    }

    suspend fun fetchTicketByReference(referenceNumber: String): Result<TicketRecord?> =
        withContext(Dispatchers.IO) {
            if (!isConfigured()) {
                return@withContext Result.failure(
                    IllegalStateException("Supabase n'est pas configuré.")
                )
            }
            runCatching {
                val url = "${SupabaseConfig.baseUrl}/rest/v1/${SupabaseConfig.TICKETS_TABLE}"
                    .toHttpUrlOrNull()!!
                    .newBuilder()
                    .addQueryParameter("reference_number", "eq.${referenceNumber.trim().uppercase()}")
                    .addQueryParameter("select", "*")
                    .addQueryParameter("limit", "1")
                    .build()

                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", SupabaseConfig.anonKey)
                    .addHeader("Authorization", "Bearer ${SupabaseConfig.anonKey}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IOException(parseSupabaseError(response.code, bodyString))
                    }
                    json.decodeFromString<List<TicketRecord>>(bodyString).firstOrNull()
                }
            }
        }

    suspend fun fetchTicketsByReferences(references: List<String>): Result<List<TicketRecord>> =
        withContext(Dispatchers.IO) {
            if (!isConfigured() || references.isEmpty()) {
                return@withContext Result.success(emptyList())
            }
            runCatching {
                val inClause = "(${references.joinToString(",") { it.trim().uppercase() }})"
                val url = "${SupabaseConfig.baseUrl}/rest/v1/${SupabaseConfig.TICKETS_TABLE}"
                    .toHttpUrlOrNull()!!
                    .newBuilder()
                    .addQueryParameter("reference_number", "in.$inClause")
                    .addQueryParameter("select", "*")
                    .addQueryParameter("order", "received_at.desc")
                    .build()

                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", SupabaseConfig.anonKey)
                    .addHeader("Authorization", "Bearer ${SupabaseConfig.anonKey}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IOException(parseSupabaseError(response.code, bodyString))
                    }
                    json.decodeFromString<List<TicketRecord>>(bodyString)
                }
            }
        }

    suspend fun signInAdmin(email: String, password: String): Result<AdminSession> =
        withContext(Dispatchers.IO) {
            if (!isConfigured()) {
                return@withContext Result.failure(
                    IllegalStateException(
                        "Supabase n'est pas configuré. Renseignez SUPABASE_URL et SUPABASE_ANON_KEY."
                    )
                )
            }
            runCatching {
                val endpoint = "${SupabaseConfig.baseUrl}/auth/v1/token?grant_type=password"
                val authPayload = SupabaseAuthRequest(email = email.trim(), password = password)
                val request = Request.Builder()
                    .url(endpoint)
                    .addHeader("apikey", SupabaseConfig.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(json.encodeToString(authPayload).toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IOException(
                            if (response.code == 400 || response.code == 401) {
                                "Identifiant ou mot de passe administrateur incorrect."
                            } else {
                                parseSupabaseError(response.code, bodyString)
                            }
                        )
                    }
                    val authResp = json.decodeFromString<SupabaseAuthResponse>(bodyString)
                    if (authResp.accessToken.isBlank()) {
                        throw IOException("Jeton d'accès administrateur manquant.")
                    }
                    AdminSession(
                        accessToken = authResp.accessToken,
                        email = authResp.user?.email ?: email.trim()
                    )
                }
            }
        }

    suspend fun fetchAllTicketsAsAdmin(accessToken: String): Result<List<TicketRecord>> =
        withContext(Dispatchers.IO) {
            if (!isConfigured()) {
                return@withContext Result.failure(
                    IllegalStateException("Supabase n'est pas configuré.")
                )
            }
            runCatching {
                val url = "${SupabaseConfig.baseUrl}/rest/v1/${SupabaseConfig.TICKETS_TABLE}"
                    .toHttpUrlOrNull()!!
                    .newBuilder()
                    .addQueryParameter("select", "*")
                    .addQueryParameter("order", "received_at.desc")
                    .build()

                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", SupabaseConfig.anonKey)
                    .addHeader("Authorization", "Bearer $accessToken")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        if (response.code == 401 || response.code == 403) {
                            throw SecurityException("Session administrateur expirée ou non autorisée.")
                        }
                        throw IOException(parseSupabaseError(response.code, bodyString))
                    }
                    json.decodeFromString<List<TicketRecord>>(bodyString)
                }
            }
        }

    suspend fun updateTicketAsAdmin(
        accessToken: String,
        ticketId: String,
        newStatus: TicketStatus,
        extractedCode: String?,
        ticketDatetime: String?,
        adminNote: String?
    ): Result<TicketRecord> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext Result.failure(
                IllegalStateException("Supabase n'est pas configuré.")
            )
        }
        runCatching {
            val url = "${SupabaseConfig.baseUrl}/rest/v1/${SupabaseConfig.TICKETS_TABLE}"
                .toHttpUrlOrNull()!!
                .newBuilder()
                .addQueryParameter("id", "eq.$ticketId")
                .build()

            val validatedAt = if (newStatus == TicketStatus.AUTHENTICATED) {
                DateTimeFormatterUtil.currentIsoUtc()
            } else {
                null
            }

            val payload = TicketUpdatePayload(
                status = newStatus.apiValue,
                extractedCode = extractedCode?.trim()?.takeIf { it.isNotEmpty() },
                ticketDatetime = ticketDatetime?.trim()?.takeIf { it.isNotEmpty() },
                adminNote = adminNote?.trim()?.takeIf { it.isNotEmpty() },
                validatedAt = validatedAt
            )

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", SupabaseConfig.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .patch(json.encodeToString(payload).toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    if (response.code == 401 || response.code == 403) {
                        throw SecurityException("Session administrateur expirée ou non autorisée.")
                    }
                    throw IOException(parseSupabaseError(response.code, bodyString))
                }
                json.decodeFromString<List<TicketRecord>>(bodyString).firstOrNull()
                    ?: throw IOException("Ticket introuvable lors de la mise à jour.")
            }
        }
    }

    suspend fun downloadPhotoBytes(photoUrl: String, accessToken: String?): Result<ByteArray> =
        withContext(Dispatchers.IO) {
            runCatching {
                val builder = Request.Builder().url(photoUrl).get()
                if (!accessToken.isNullOrBlank()) {
                    builder.addHeader("apikey", SupabaseConfig.anonKey)
                    builder.addHeader("Authorization", "Bearer $accessToken")
                }
                httpClient.newCall(builder.build()).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("Téléchargement impossible (code ${response.code}).")
                    }
                    response.body?.bytes() ?: throw IOException("Image vide.")
                }
            }
        }

    private fun parseSupabaseError(code: Int, body: String): String {
        val compact = body.take(220).ifBlank { "Erreur HTTP $code" }
        return "Erreur Supabase ($code) : $compact"
    }
}
