package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AdminSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "transcash_auth_prefs")

class LocalPreferencesRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    private val trackedRefsKey = stringPreferencesKey("tracked_references_json")
    private val adminTokenKey = stringPreferencesKey("admin_access_token")
    private val adminEmailKey = stringPreferencesKey("admin_email")

    val trackedReferences: Flow<List<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[trackedRefsKey] ?: return@map emptyList()
        runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    val adminSession: Flow<AdminSession?> = context.dataStore.data.map { prefs ->
        val token = prefs[adminTokenKey]
        val email = prefs[adminEmailKey]
        if (!token.isNullOrBlank() && !email.isNullOrBlank()) {
            AdminSession(accessToken = token, email = email)
        } else {
            null
        }
    }

    suspend fun addTrackedReference(referenceNumber: String) {
        val normalized = referenceNumber.trim().uppercase()
        if (normalized.isEmpty()) return
        context.dataStore.edit { prefs ->
            val current = prefs[trackedRefsKey]?.let {
                runCatching { json.decodeFromString<List<String>>(it) }.getOrDefault(emptyList())
            } ?: emptyList()
            val updated = (listOf(normalized) + current.filterNot { it == normalized }).take(25)
            prefs[trackedRefsKey] = json.encodeToString(updated)
        }
    }

    suspend fun saveAdminSession(session: AdminSession) {
        context.dataStore.edit { prefs ->
            prefs[adminTokenKey] = session.accessToken
            prefs[adminEmailKey] = session.email
        }
    }

    suspend fun clearAdminSession() {
        context.dataStore.edit { prefs ->
            prefs.remove(adminTokenKey)
            prefs.remove(adminEmailKey)
        }
    }
}
