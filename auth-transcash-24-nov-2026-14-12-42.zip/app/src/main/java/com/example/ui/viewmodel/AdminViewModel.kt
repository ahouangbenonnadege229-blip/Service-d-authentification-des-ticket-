package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.LocalPreferencesRepository
import com.example.data.PhotoStorageHelper
import com.example.data.SupabaseConfig
import com.example.data.SupabaseTicketRepository
import com.example.model.AdminSession
import com.example.model.TicketRecord
import com.example.model.TicketStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
    val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured,
    val session: AdminSession? = null,
    val loginEmail: String = "",
    val loginPassword: String = "",
    val isLoggingIn: Boolean = false,
    val loginError: String? = null,
    val tickets: List<TicketRecord> = emptyList(),
    val isLoadingTickets: Boolean = false,
    val ticketsError: String? = null,
    val searchQuery: String = "",
    val selectedStatusFilter: TicketStatus? = null,
    val selectedTicketId: String? = null,
    val isUpdatingTicket: Boolean = false,
    val isDownloadingPhoto: Boolean = false,
    val feedbackMessage: String? = null
) {
    val filteredTickets: List<TicketRecord>
        get() {
            val q = searchQuery.trim().lowercase()
            return tickets.filter { ticket ->
                val matchesStatus =
                    selectedStatusFilter == null || ticket.ticketStatus == selectedStatusFilter
                val matchesQuery = q.isEmpty() ||
                    ticket.referenceNumber.lowercase().contains(q) ||
                    ticket.fullName.lowercase().contains(q) ||
                    ticket.phoneNumber.lowercase().contains(q) ||
                    (ticket.extractedCode?.lowercase()?.contains(q) == true) ||
                    (ticket.ticketDatetime?.lowercase()?.contains(q) == true)
                matchesStatus && matchesQuery
            }
        }

    val selectedTicket: TicketRecord?
        get() = tickets.firstOrNull { it.id == selectedTicketId }
}

class AdminViewModel(
    private val appContext: Context,
    private val repository: SupabaseTicketRepository,
    private val localPrefs: LocalPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            localPrefs.adminSession.collect { savedSession ->
                _uiState.update { it.copy(session = savedSession) }
                if (savedSession != null && _uiState.value.tickets.isEmpty() && repository.isConfigured()) {
                    refreshTickets(savedSession.accessToken)
                }
            }
        }
    }

    fun onLoginEmailChange(email: String) {
        _uiState.update { it.copy(loginEmail = email, loginError = null) }
    }

    fun onLoginPasswordChange(password: String) {
        _uiState.update { it.copy(loginPassword = password, loginError = null) }
    }

    fun signIn() {
        val current = _uiState.value
        val email = current.loginEmail.trim()
        val password = current.loginPassword

        if (email.isEmpty() || !email.contains("@")) {
            _uiState.update { it.copy(loginError = "Veuillez saisir votre identifiant e-mail.") }
            return
        }
        if (password.isEmpty()) {
            _uiState.update { it.copy(loginError = "Veuillez saisir votre mot de passe.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoggingIn = true, loginError = null) }
            repository.signInAdmin(email, password).fold(
                onSuccess = { session ->
                    localPrefs.saveAdminSession(session)
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            session = session,
                            loginPassword = "",
                            loginError = null
                        )
                    }
                    refreshTickets(session.accessToken)
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            loginError = error.message ?: "Connexion refusée."
                        )
                    }
                }
            )
        }
    }

    fun signOut() {
        viewModelScope.launch {
            localPrefs.clearAdminSession()
            _uiState.update {
                it.copy(
                    session = null,
                    tickets = emptyList(),
                    selectedTicketId = null,
                    ticketsError = null
                )
            }
        }
    }

    fun refreshTickets(explicitToken: String? = null) {
        val token = explicitToken ?: _uiState.value.session?.accessToken ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingTickets = true, ticketsError = null) }
            repository.fetchAllTicketsAsAdmin(token).fold(
                onSuccess = { list ->
                    _uiState.update { state ->
                        val keepSelected = state.selectedTicketId?.takeIf { id ->
                            list.any { it.id == id }
                        } ?: list.firstOrNull()?.id
                        state.copy(
                            tickets = list,
                            isLoadingTickets = false,
                            selectedTicketId = keepSelected,
                            ticketsError = null
                        )
                    }
                },
                onFailure = { error ->
                    if (error is SecurityException) {
                        localPrefs.clearAdminSession()
                        _uiState.update {
                            it.copy(
                                session = null,
                                isLoadingTickets = false,
                                loginError = "Votre session a expiré. Veuillez vous reconnecter."
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoadingTickets = false,
                                ticketsError = error.message ?: "Erreur lors du chargement des tickets."
                            )
                        }
                    }
                }
            )
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onStatusFilterSelected(status: TicketStatus?) {
        _uiState.update { it.copy(selectedStatusFilter = status) }
    }

    fun selectTicket(ticketId: String) {
        _uiState.update { it.copy(selectedTicketId = ticketId) }
    }

    fun updateTicket(
        ticketId: String,
        newStatus: TicketStatus,
        extractedCode: String?,
        ticketDatetime: String?,
        adminNote: String?
    ) {
        val token = _uiState.value.session?.accessToken ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isUpdatingTicket = true, feedbackMessage = null) }
            repository.updateTicketAsAdmin(
                accessToken = token,
                ticketId = ticketId,
                newStatus = newStatus,
                extractedCode = extractedCode,
                ticketDatetime = ticketDatetime,
                adminNote = adminNote
            ).fold(
                onSuccess = { updated ->
                    _uiState.update { state ->
                        val newList = state.tickets.map {
                            if (it.id == updated.id) updated else it
                        }
                        state.copy(
                            tickets = newList,
                            isUpdatingTicket = false,
                            feedbackMessage = "Statut mis à jour : ${updated.ticketStatus.labelFr}"
                        )
                    }
                },
                onFailure = { error ->
                    if (error is SecurityException) {
                        localPrefs.clearAdminSession()
                    }
                    _uiState.update {
                        it.copy(
                            isUpdatingTicket = false,
                            feedbackMessage = error.message ?: "Échec de la mise à jour."
                        )
                    }
                }
            )
        }
    }

    fun downloadTicketPhoto(ticket: TicketRecord) {
        val token = _uiState.value.session?.accessToken
        viewModelScope.launch {
            _uiState.update { it.copy(isDownloadingPhoto = true, feedbackMessage = null) }
            repository.downloadPhotoBytes(ticket.photoUrl, token).fold(
                onSuccess = { bytes ->
                    val saved = PhotoStorageHelper.saveImageToDevice(
                        context = appContext,
                        bytes = bytes,
                        displayName = "ticket_${ticket.referenceNumber}"
                    )
                    _uiState.update {
                        it.copy(
                            isDownloadingPhoto = false,
                            feedbackMessage = if (saved) {
                                "Photo enregistrée dans la galerie (Images/AuthTranscash)."
                            } else {
                                "Impossible d'enregistrer la photo sur l'appareil."
                            }
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isDownloadingPhoto = false,
                            feedbackMessage = error.message ?: "Impossible de télécharger la photo."
                        )
                    }
                }
            )
        }
    }

    fun clearFeedback() {
        _uiState.update { it.copy(feedbackMessage = null) }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AdminViewModel(
                        appContext = container.appContext,
                        repository = container.supabaseRepository,
                        localPrefs = container.localPreferences
                    ) as T
                }
            }
    }
}
