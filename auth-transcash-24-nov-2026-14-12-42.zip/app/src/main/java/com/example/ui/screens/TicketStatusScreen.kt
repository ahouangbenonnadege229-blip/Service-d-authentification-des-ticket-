package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DateTimeFormatterUtil
import com.example.model.TicketRecord
import com.example.model.TicketStatus
import com.example.ui.components.FullScreenZoomablePhotoDialog
import com.example.ui.components.MetadataInfoRow
import com.example.ui.components.StatusBadge
import com.example.ui.theme.Amber100
import com.example.ui.theme.Amber600
import com.example.ui.theme.Crimson100
import com.example.ui.theme.Crimson600
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Emerald700
import com.example.ui.viewmodel.TicketTrackingViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketStatusScreen(
    referenceNumber: String,
    viewModel: TicketTrackingViewModel,
    onBack: () -> Unit,
    onSubmitAnother: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var showZoomPhoto by remember { mutableStateOf(false) }

    BackHandler { onBack() }

    LaunchedEffect(referenceNumber) {
        viewModel.loadTicketStatus(referenceNumber, silent = false)
    }

    // Live polling every 8 seconds while ticket is pending administrator validation
    LaunchedEffect(referenceNumber, uiState.activeTicket?.ticketStatus) {
        if (uiState.activeTicket?.ticketStatus == TicketStatus.PENDING) {
            while (true) {
                delay(8000)
                viewModel.loadTicketStatus(referenceNumber, silent = true)
            }
        }
    }

    val ticket = uiState.activeTicket?.takeIf {
        it.referenceNumber.equals(referenceNumber, ignoreCase = true)
    }

    if (showZoomPhoto && ticket != null) {
        FullScreenZoomablePhotoDialog(
            model = ticket.photoUrl,
            title = ticket.referenceNumber,
            onDismiss = { showZoomPhoto = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.tracking_screen_title)) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("status_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.loadTicketStatus(referenceNumber, silent = false) },
                        modifier = Modifier.testTag("status_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.btn_refresh_status)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when {
                    uiState.isLoadingActive && ticket == null -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }

                    ticket == null -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = uiState.errorMessage ?: "Ticket introuvable.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                OutlinedButton(onClick = {
                                    viewModel.loadTicketStatus(referenceNumber, silent = false)
                                }) {
                                    Text(stringResource(R.string.btn_refresh_status))
                                }
                            }
                        }
                    }

                    else -> {
                        StatusHeroCard(ticket = ticket)

                        // Metadata details card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_reference),
                                    value = ticket.referenceNumber,
                                    isMonospace = true,
                                    icon = Icons.Filled.ConfirmationNumber,
                                    trailingContent = {
                                        IconButton(
                                            onClick = {
                                                clipboard.setText(AnnotatedString(ticket.referenceNumber))
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.ContentCopy,
                                                contentDescription = "Copier la référence",
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_full_name),
                                    value = ticket.fullName,
                                    icon = Icons.Filled.Person
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_phone),
                                    value = ticket.phoneNumber,
                                    icon = Icons.Filled.Phone
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_received_at),
                                    value = DateTimeFormatterUtil.formatIsoToFrench(ticket.receivedAt),
                                    icon = Icons.Filled.Schedule
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_ticket_code),
                                    value = ticket.extractedCode
                                        ?: stringResource(R.string.value_unreadable),
                                    isMonospace = !ticket.extractedCode.isNullOrBlank(),
                                    icon = Icons.Filled.QrCode2
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                MetadataInfoRow(
                                    label = stringResource(R.string.label_ticket_datetime),
                                    value = ticket.ticketDatetime
                                        ?: stringResource(R.string.value_unreadable),
                                    icon = Icons.Filled.CalendarToday
                                )

                                if (!ticket.adminNote.isNullOrBlank()) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                    MetadataInfoRow(
                                        label = stringResource(R.string.label_admin_note),
                                        value = ticket.adminNote
                                    )
                                }
                            }
                        }

                        // Ticket photo thumbnail
                        if (ticket.photoUrl.isNotBlank()) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = MaterialTheme.shapes.large,
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.cd_ticket_photo),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    AsyncImage(
                                        model = ticket.photoUrl,
                                        contentDescription = stringResource(R.string.cd_ticket_photo),
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(190.dp)
                                            .clip(MaterialTheme.shapes.medium)
                                            .clickable { showZoomPhoto = true }
                                    )
                                }
                            }
                        }

                        // Actions: Refresh + Share via WhatsApp / Messaging + Submit another
                        if (ticket.ticketStatus == TicketStatus.PENDING) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.loadTicketStatus(referenceNumber, silent = false)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 50.dp)
                                    .testTag("manual_refresh_status_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.btn_refresh_status))
                            }
                        }

                        Button(
                            onClick = {
                                val shareText = buildString {
                                    append("SERVICE D’AUTHENTIFICATION TRANSCASH\n")
                                    append("Référence : ${ticket.referenceNumber}\n")
                                    append("Client : ${ticket.fullName}\n")
                                    append("Statut : ${ticket.ticketStatus.labelFr}\n")
                                    append("Reçu le : ${DateTimeFormatterUtil.formatIsoToFrench(ticket.receivedAt)}")
                                }
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(
                                    Intent.createChooser(sendIntent, "Partager le ticket")
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .testTag("share_ticket_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.btn_share_whatsapp))
                        }

                        OutlinedButton(
                            onClick = onSubmitAnother,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 50.dp)
                                .testTag("submit_another_button")
                        ) {
                            Text(stringResource(R.string.btn_new_ticket))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun StatusHeroCard(ticket: TicketRecord) {
    val status = ticket.ticketStatus
    var animateIn by remember(status) { mutableStateOf(false) }
    LaunchedEffect(status) { animateIn = true }

    val iconScale by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0.7f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "status_icon_scale"
    )

    when (status) {
        TicketStatus.AUTHENTICATED -> {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("authenticated_confirmation_card"),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(2.dp, Emerald600)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Emerald100,
                        modifier = Modifier
                            .size(96.dp)
                            .scale(iconScale)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = stringResource(R.string.status_authenticated),
                                tint = Emerald600,
                                modifier = Modifier.size(60.dp)
                            )
                        }
                    }

                    StatusBadge(status = TicketStatus.AUTHENTICATED)

                    Text(
                        text = stringResource(R.string.confirmation_title),
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = Emerald700,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = stringResource(R.string.confirmation_subtitle),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        TicketStatus.PENDING -> {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pending_status_card"),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, Amber600)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Amber100,
                        modifier = Modifier
                            .size(80.dp)
                            .scale(iconScale)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.HourglassTop,
                                contentDescription = stringResource(R.string.status_pending),
                                tint = Amber600,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }

                    StatusBadge(status = TicketStatus.PENDING)

                    Text(
                        text = stringResource(R.string.pending_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = stringResource(R.string.pending_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        TicketStatus.REFUSED -> {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("refused_status_card"),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, Crimson600)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Crimson100,
                        modifier = Modifier
                            .size(80.dp)
                            .scale(iconScale)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Cancel,
                                contentDescription = stringResource(R.string.status_refused),
                                tint = Crimson600,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    StatusBadge(status = TicketStatus.REFUSED)

                    Text(
                        text = stringResource(R.string.refused_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = Crimson600,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = stringResource(R.string.refused_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
