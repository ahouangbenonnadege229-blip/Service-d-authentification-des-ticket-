package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.LocalPreferencesRepository
import com.example.data.PhotoStorageHelper
import com.example.data.SupabaseConfig
import com.example.data.SupabaseTicketRepository
import com.example.data.TicketOcrExtractor
import com.example.model.OcrExtractionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ClientFormUiState(
    val fullName: String = "",
    val phoneNumber: String = "",
    val selectedPhotoUri: Uri? = null,
    val ocrLoading: Boolean = false,
    val ocrResult: OcrExtractionResult? = null,
    val fullNameError: String? = null,
    val phoneError: String? = null,
    val photoError: String? = null,
    val isSubmitting: Boolean = false,
    val submitError: String? = null,
    val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured,
    val submittedReference: String? = null
)

class ClientFormViewModel(
    private val appContext: Context,
    private val repository: SupabaseTicketRepository,
    private val localPrefs: LocalPreferencesRepository,
    private val ocrExtractor: TicketOcrExtractor
) : ViewModel() {

    private val _uiState = MutableStateFlow(ClientFormUiState())
    val uiState: StateFlow<ClientFormUiState> = _uiState.asStateFlow()

    fun onFullNameChange(value: String) {
        _uiState.update {
            it.copy(fullName = value, fullNameError = null, submitError = null)
        }
    }

    fun onPhoneNumberChange(value: String) {
        _uiState.update {
            it.copy(phoneNumber = value, phoneError = null, submitError = null)
        }
    }

    fun onPhotoSelected(uri: Uri) {
        _uiState.update {
            it.copy(
                selectedPhotoUri = uri,
                photoError = null,
                submitError = null,
                ocrLoading = true,
                ocrResult = null
            )
        }
        viewModelScope.launch {
            val extraction = ocrExtractor.extractFromUri(uri)
            _uiState.update { state ->
                if (state.selectedPhotoUri == uri) {
                    state.copy(ocrLoading = false, ocrResult = extraction)
                } else {
                    state
                }
            }
        }
    }

    fun clearSubmitError() {
        _uiState.update { it.copy(submitError = null) }
    }

    fun submitTicket() {
        val current = _uiState.value
        val trimmedName = current.fullName.trim()
        val trimmedPhone = current.phoneNumber.trim()
        val digitsCount = trimmedPhone.count { it.isDigit() }

        val nameErr = if (trimmedName.length < 2) {
            "Veuillez saisir votre nom et prénom."
        } else null

        val phoneErr = if (digitsCount < 6) {
            "Veuillez saisir un numéro de téléphone valide."
        } else null

        val photoErr = if (current.selectedPhotoUri == null) {
            "Veuillez ajouter la photo de votre ticket TRANSCASH."
        } else null

        if (nameErr != null || phoneErr != null || photoErr != null) {
            _uiState.update {
                it.copy(
                    fullNameError = nameErr,
                    phoneError = phoneErr,
                    photoError = photoErr
                )
            }
            return
        }

        val photoUri = current.selectedPhotoUri ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, submitError = null) }
            try {
                val jpegBytes = PhotoStorageHelper.readAndCompressJpeg(appContext, photoUri)
                val ocr = current.ocrResult ?: ocrExtractor.extractFromUri(photoUri)
                val result = repository.submitTicket(
                    fullName = trimmedName,
                    phoneNumber = trimmedPhone,
                    jpegBytes = jpegBytes,
                    extractedCode = ocr.extractedCode,
                    ticketDateTime = ocr.ticketDateTime
                )

                result.fold(
                    onSuccess = { createdTicket ->
                        localPrefs.addTrackedReference(createdTicket.referenceNumber)
                        _uiState.update {
                            it.copy(
                                isSubmitting = false,
                                submittedReference = createdTicket.referenceNumber
                            )
                        }
                    },
                    onFailure = { error ->
                        _uiState.update {
                            it.copy(
                                isSubmitting = false,
                                submitError = error.message
                                    ?: "Erreur lors de l'envoi du ticket. Veuillez réessayer."
                            )
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isSubmitting = false,
                        submitError = e.message
                            ?: "Impossible de préparer la photo pour l'envoi."
                    )
                }
            }
        }
    }

    fun consumeSubmittedNavigation(resetForm: Boolean = true) {
        _uiState.update { state ->
            if (resetForm) {
                ClientFormUiState(isSupabaseConfigured = state.isSupabaseConfigured)
            } else {
                state.copy(submittedReference = null)
            }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ClientFormViewModel(
                        appContext = container.appContext,
                        repository = container.supabaseRepository,
                        localPrefs = container.localPreferences,
                        ocrExtractor = container.ocrExtractor
                    ) as T
                }
            }
    }
}
