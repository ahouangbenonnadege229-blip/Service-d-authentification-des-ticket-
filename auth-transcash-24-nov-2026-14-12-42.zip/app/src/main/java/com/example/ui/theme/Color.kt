package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Sovereign FinTech Slate Navy
val SlateNavy900 = Color(0xFF0F172A)
val SlateNavy800 = Color(0xFF1E293B)
val SlateNavy700 = Color(0xFF334155)
val SlateNavy100 = Color(0xFFF1F5F9)
val SlateNavy50 = Color(0xFFF8FAFC)

// Emerald Verification Accent
val Emerald700 = Color(0xFF047857)
val Emerald600 = Color(0xFF059669)
val Emerald500 = Color(0xFF10B981)
val Emerald100 = Color(0xFFD1FAE5)
val Emerald50 = Color(0xFFECFDF5)

// Status Semantic Tokens
val Amber600 = Color(0xFFD97706)
val Amber100 = Color(0xFFFEF3C7)
val Amber900 = Color(0xFF78350F)

val Crimson600 = Color(0xFFDC2626)
val Crimson100 = Color(0xFFFEE2E2)
val Crimson900 = Color(0xFF7F1D1D)

// Surfaces & Neutrals
val PureWhite = Color(0xFFFFFFFF)
val SlateBorder = Color(0xFFE2E8F0)
val SlateMuted = Color(0xFF64748B)
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkBorder = Color(0xFF374151)
