package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DateTimeFormatterUtil
import com.example.model.TicketRecord
import com.example.model.TicketStatus
import com.example.ui.components.FullScreenZoomablePhotoDialog
import com.example.ui.components.MetadataInfoRow
import com.example.ui.components.StatusBadge
import com.example.ui.theme.Amber100
import com.example.ui.theme.Amber900
import com.example.ui.theme.Crimson100
import com.example.ui.theme.Crimson900
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald700

@Composable
fun AdminTicketDetailContent(
    ticket: TicketRecord,
    isUpdating: Boolean,
    isDownloadingPhoto: Boolean,
    onUpdateTicket: (
        newStatus: TicketStatus,
        extractedCode: String?,
        ticketDatetime: String?,
        adminNote: String?
    ) -> Unit,
    onDownloadPhoto: (TicketRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var editedCode by remember(ticket.id, ticket.extractedCode) {
        mutableStateOf(ticket.extractedCode.orEmpty())
    }
    var editedTicketDateTime by remember(ticket.id, ticket.ticketDatetime) {
        mutableStateOf(ticket.ticketDatetime.orEmpty())
    }
    var editedNote by remember(ticket.id, ticket.adminNote) {
        mutableStateOf(ticket.adminNote.orEmpty())
    }
    var selectedStatus by remember(ticket.id, ticket.status) {
        mutableStateOf(ticket.ticketStatus)
    }
    var showFullPhoto by remember { mutableStateOf(false) }

    if (showFullPhoto && ticket.photoUrl.isNotBlank()) {
        FullScreenZoomablePhotoDialog(
            model = ticket.photoUrl,
            title = ticket.referenceNumber,
            onDismiss = { showFullPhoto = false },
            onDownload = { onDownloadPhoto(ticket) },
            isDownloading = isDownloadingPhoto
        )
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Photo Card with full-screen zoom & download
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.cd_ticket_photo),
                        style = MaterialTheme.typography.titleMedium
                    )
                    StatusBadge(status = ticket.ticketStatus)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable(enabled = ticket.photoUrl.isNotBlank()) {
                            showFullPhoto = true
                        }
                        .testTag("admin_photo_preview")
                ) {
                    AsyncImage(
                        model = ticket.photoUrl,
                        contentDescription = stringResource(R.string.cd_ticket_photo),
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp),
                        shape = RoundedCornerShape(50),
                        color = Color.Black.copy(alpha = 0.7f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ZoomIn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.btn_view_full_photo),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showFullPhoto = true },
                        enabled = ticket.photoUrl.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("admin_view_full_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ZoomIn,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.btn_view_full_photo),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    Button(
                        onClick = { onDownloadPhoto(ticket) },
                        enabled = ticket.photoUrl.isNotBlank() && !isDownloadingPhoto,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("admin_download_photo_button")
                    ) {
                        if (isDownloadingPhoto) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Download,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.btn_download_photo),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }
        }

        // Client & Reception Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MetadataInfoRow(
                    label = stringResource(R.string.label_reference),
                    value = ticket.referenceNumber,
                    isMonospace = true,
                    icon = Icons.Filled.ConfirmationNumber,
                    trailingContent = {
                        IconButton(onClick = {
                            clipboard.setText(AnnotatedString(ticket.referenceNumber))
                        }) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "Copier",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                MetadataInfoRow(
                    label = stringResource(R.string.label_full_name),
                    value = ticket.fullName,
                    icon = Icons.Filled.Person
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                MetadataInfoRow(
                    label = stringResource(R.string.label_phone),
                    value = ticket.phoneNumber,
                    icon = Icons.Filled.Phone,
                    trailingContent = {
                        Row {
                            IconButton(onClick = {
                                clipboard.setText(AnnotatedString(ticket.phoneNumber))
                            }) {
                                Icon(
                                    imageVector = Icons.Filled.ContentCopy,
                                    contentDescription = "Copier le numéro",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = {
                                val dialIntent = Intent(
                                    Intent.ACTION_DIAL,
                                    Uri.parse("tel:${ticket.phoneNumber}")
                                )
                                context.startActivity(dialIntent)
                            }) {
                                Icon(
                                    imageVector = Icons.Filled.Call,
                                    contentDescription = "Appeler le client",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                MetadataInfoRow(
                    label = stringResource(R.string.label_received_at),
                    value = DateTimeFormatterUtil.formatIsoToFrench(ticket.receivedAt),
                    icon = Icons.Filled.Schedule
                )
            }
        }

        // Ticket Verification & Status Update Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Vérification et statut du ticket",
                    style = MaterialTheme.typography.titleMedium
                )

                OutlinedTextField(
                    value = editedCode,
                    onValueChange = { editedCode = it },
                    label = { Text(stringResource(R.string.label_ticket_code)) },
                    placeholder = { Text(stringResource(R.string.value_unreadable)) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.QrCode2, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_ticket_code_input")
                )

                OutlinedTextField(
                    value = editedTicketDateTime,
                    onValueChange = { editedTicketDateTime = it },
                    label = { Text(stringResource(R.string.label_ticket_datetime)) },
                    placeholder = { Text(stringResource(R.string.value_unreadable)) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.CalendarToday, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_ticket_datetime_input")
                )

                OutlinedTextField(
                    value = editedNote,
                    onValueChange = { editedNote = it },
                    label = { Text(stringResource(R.string.label_admin_note)) },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_note_input")
                )

                Text(
                    text = "Décision / Statut",
                    style = MaterialTheme.typography.titleSmall
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TicketStatus.entries.forEach { statusOption ->
                        val isSelected = selectedStatus == statusOption
                        val (chipBg, chipText, chipIcon) = when (statusOption) {
                            TicketStatus.PENDING -> Triple(
                                Amber100,
                                Amber900,
                                Icons.Filled.HourglassTop
                            )
                            TicketStatus.AUTHENTICATED -> Triple(
                                Emerald100,
                                Emerald700,
                                Icons.Filled.CheckCircle
                            )
                            TicketStatus.REFUSED -> Triple(
                                Crimson100,
                                Crimson900,
                                Icons.Filled.Cancel
                            )
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedStatus = statusOption },
                            label = {
                                Text(
                                    text = statusOption.labelFr,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = chipIcon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = chipBg,
                                selectedLabelColor = chipText,
                                selectedLeadingIconColor = chipText
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("admin_status_chip_${statusOption.name.lowercase()}")
                        )
                    }
                }

                Button(
                    onClick = {
                        onUpdateTicket(
                            selectedStatus,
                            editedCode,
                            editedTicketDateTime,
                            editedNote
                        )
                    },
                    enabled = !isUpdating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = Color.White
                    ),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .testTag("admin_save_ticket_button")
                ) {
                    if (isUpdating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Save,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.btn_save_ticket_details),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
