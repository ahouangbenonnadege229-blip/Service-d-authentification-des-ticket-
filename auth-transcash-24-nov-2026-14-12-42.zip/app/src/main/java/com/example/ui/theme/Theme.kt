package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = SlateNavy900,
    onPrimary = PureWhite,
    primaryContainer = SlateNavy100,
    onPrimaryContainer = SlateNavy900,
    secondary = Emerald600,
    onSecondary = PureWhite,
    secondaryContainer = Emerald100,
    onSecondaryContainer = Emerald700,
    tertiary = Amber600,
    onTertiary = PureWhite,
    tertiaryContainer = Amber100,
    onTertiaryContainer = Amber900,
    error = Crimson600,
    onError = PureWhite,
    errorContainer = Crimson100,
    onErrorContainer = Crimson900,
    background = SlateNavy50,
    onBackground = SlateNavy900,
    surface = PureWhite,
    onSurface = SlateNavy900,
    surfaceVariant = SlateNavy100,
    onSurfaceVariant = SlateMuted,
    outline = SlateBorder,
    outlineVariant = SlateNavy100
)

private val DarkColorScheme = darkColorScheme(
    primary = Emerald500,
    onPrimary = SlateNavy900,
    primaryContainer = SlateNavy800,
    onPrimaryContainer = PureWhite,
    secondary = Emerald500,
    onSecondary = SlateNavy900,
    secondaryContainer = Emerald700,
    onSecondaryContainer = Emerald50,
    tertiary = Amber600,
    onTertiary = PureWhite,
    tertiaryContainer = Amber900,
    onTertiaryContainer = Amber100,
    error = Crimson600,
    onError = PureWhite,
    errorContainer = Crimson900,
    onErrorContainer = Crimson100,
    background = DarkBackground,
    onBackground = SlateNavy50,
    surface = DarkSurface,
    onSurface = SlateNavy50,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = SlateNavy100,
    outline = DarkBorder,
    outlineVariant = DarkSurfaceVariant
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun TranscashAuthTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
