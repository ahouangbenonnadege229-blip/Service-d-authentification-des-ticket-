package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.LocalPreferencesRepository
import com.example.data.SupabaseConfig
import com.example.data.SupabaseTicketRepository
import com.example.model.TicketRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TicketTrackingUiState(
    val searchQuery: String = "",
    val recentTickets: List<TicketRecord> = emptyList(),
    val isLoadingRecent: Boolean = false,
    val activeTicket: TicketRecord? = null,
    val isLoadingActive: Boolean = false,
    val errorMessage: String? = null,
    val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured
)

class TicketTrackingViewModel(
    private val repository: SupabaseTicketRepository,
    private val localPrefs: LocalPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TicketTrackingUiState())
    val uiState: StateFlow<TicketTrackingUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            localPrefs.trackedReferences.collect { refs ->
                if (refs.isNotEmpty() && repository.isConfigured()) {
                    loadTicketsForReferences(refs)
                } else {
                    _uiState.update { it.copy(recentTickets = emptyList(), isLoadingRecent = false) }
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query, errorMessage = null) }
    }

    fun refreshRecentTickets() {
        viewModelScope.launch {
            val refs = localPrefs.trackedReferences.first()
            if (refs.isEmpty()) {
                _uiState.update { it.copy(recentTickets = emptyList(), isLoadingRecent = false) }
                return@launch
            }
            loadTicketsForReferences(refs)
        }
    }

    private suspend fun loadTicketsForReferences(refs: List<String>) {
        _uiState.update { it.copy(isLoadingRecent = true, errorMessage = null) }
        repository.fetchTicketsByReferences(refs).fold(
            onSuccess = { list ->
                _uiState.update { it.copy(recentTickets = list, isLoadingRecent = false) }
            },
            onFailure = { error ->
                _uiState.update {
                    it.copy(
                        isLoadingRecent = false,
                        errorMessage = error.message
                    )
                }
            }
        )
    }

    fun lookupByReference(reference: String, onFound: (String) -> Unit = {}) {
        val cleaned = reference.trim().uppercase()
        if (cleaned.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Veuillez saisir un numéro de référence.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingActive = true, errorMessage = null) }
            repository.fetchTicketByReference(cleaned).fold(
                onSuccess = { ticket ->
                    if (ticket == null) {
                        _uiState.update {
                            it.copy(
                                isLoadingActive = false,
                                errorMessage = "Aucun ticket trouvé pour la référence $cleaned."
                            )
                        }
                    } else {
                        localPrefs.addTrackedReference(ticket.referenceNumber)
                        _uiState.update {
                            it.copy(
                                activeTicket = ticket,
                                isLoadingActive = false,
                                errorMessage = null
                            )
                        }
                        onFound(ticket.referenceNumber)
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoadingActive = false,
                            errorMessage = error.message ?: "Erreur lors de la recherche."
                        )
                    }
                }
            )
        }
    }

    fun loadTicketStatus(referenceNumber: String, silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) {
                _uiState.update { it.copy(isLoadingActive = true, errorMessage = null) }
            }
            repository.fetchTicketByReference(referenceNumber).fold(
                onSuccess = { ticket ->
                    _uiState.update { state ->
                        val updatedRecent = if (ticket != null) {
                            val without = state.recentTickets.filterNot {
                                it.referenceNumber == ticket.referenceNumber
                            }
                            listOf(ticket) + without
                        } else {
                            state.recentTickets
                        }
                        state.copy(
                            activeTicket = ticket,
                            recentTickets = updatedRecent,
                            isLoadingActive = false,
                            errorMessage = if (ticket == null && !silent) {
                                "Ticket introuvable."
                            } else null
                        )
                    }
                },
                onFailure = { error ->
                    if (!silent) {
                        _uiState.update {
                            it.copy(
                                isLoadingActive = false,
                                errorMessage = error.message ?: "Impossible d'actualiser le statut."
                            )
                        }
                    }
                }
            )
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return TicketTrackingViewModel(
                        repository = container.supabaseRepository,
                        localPrefs = container.localPreferences
                    ) as T
                }
            }
    }
}
