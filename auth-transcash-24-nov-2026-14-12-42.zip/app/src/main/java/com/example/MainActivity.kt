package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AdminTicketDetailScreen
import com.example.ui.screens.HomeSubmissionScreen
import com.example.ui.screens.TicketStatusScreen
import com.example.ui.screens.TicketTrackingTabScreen
import com.example.ui.theme.TranscashAuthTheme
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.ClientFormViewModel
import com.example.ui.viewmodel.TicketTrackingViewModel
import kotlinx.serialization.Serializable

@Serializable
data object HomeRoute

@Serializable
data object TrackingRoute

@Serializable
data object AdminRoute

@Serializable
data class TicketStatusRoute(val referenceNumber: String)

@Serializable
data class AdminTicketDetailRoute(val ticketId: String)

private data class TopLevelDestination(
    val route: Any,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appContainer = AppContainer(applicationContext)
        setContent {
            val windowSizeClass = calculateWindowSizeClass(this)
            TranscashAuthTheme {
                TranscashAuthApp(
                    appContainer = appContainer,
                    widthSizeClass = windowSizeClass.widthSizeClass
                )
            }
        }
    }
}

@Composable
fun TranscashAuthApp(
    appContainer: AppContainer,
    widthSizeClass: WindowWidthSizeClass
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val clientFormViewModel: ClientFormViewModel = viewModel(
        factory = ClientFormViewModel.factory(appContainer)
    )
    val trackingViewModel: TicketTrackingViewModel = viewModel(
        factory = TicketTrackingViewModel.factory(appContainer)
    )
    val adminViewModel: AdminViewModel = viewModel(
        factory = AdminViewModel.factory(appContainer)
    )

    val topDestinations = remember {
        listOf(
            TopLevelDestination(
                route = HomeRoute,
                labelRes = R.string.nav_home,
                selectedIcon = Icons.Filled.VerifiedUser,
                unselectedIcon = Icons.Outlined.VerifiedUser,
                testTag = "nav_tab_home"
            ),
            TopLevelDestination(
                route = TrackingRoute,
                labelRes = R.string.nav_tracking,
                selectedIcon = Icons.Filled.FactCheck,
                unselectedIcon = Icons.Outlined.FactCheck,
                testTag = "nav_tab_tracking"
            ),
            TopLevelDestination(
                route = AdminRoute,
                labelRes = R.string.nav_admin,
                selectedIcon = Icons.Filled.AdminPanelSettings,
                unselectedIcon = Icons.Outlined.AdminPanelSettings,
                testTag = "nav_tab_admin"
            )
        )
    }

    val isTopLevel = currentDestination?.let { dest ->
        dest.hasRoute<HomeRoute>() ||
            dest.hasRoute<TrackingRoute>() ||
            dest.hasRoute<AdminRoute>()
    } ?: true

    val useNavigationRail = widthSizeClass != WindowWidthSizeClass.Compact
    val isExpandedScreen = widthSizeClass == WindowWidthSizeClass.Expanded

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (isTopLevel && !useNavigationRail) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    topDestinations.forEach { item ->
                        val selected = when (item.route) {
                            is HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                            is TrackingRoute -> currentDestination?.hasRoute<TrackingRoute>() == true
                            is AdminRoute -> currentDestination?.hasRoute<AdminRoute>() == true
                            else -> false
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigateTopLevel(item.route) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = stringResource(item.labelRes)
                                )
                            },
                            label = { Text(stringResource(item.labelRes)) },
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isTopLevel && useNavigationRail) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    topDestinations.forEach { item ->
                        val selected = when (item.route) {
                            is HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                            is TrackingRoute -> currentDestination?.hasRoute<TrackingRoute>() == true
                            is AdminRoute -> currentDestination?.hasRoute<AdminRoute>() == true
                            else -> false
                        }
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateTopLevel(item.route) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = stringResource(item.labelRes)
                                )
                            },
                            label = { Text(stringResource(item.labelRes)) },
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                NavHost(
                    navController = navController,
                    startDestination = HomeRoute
                ) {
                    composable<HomeRoute> {
                        HomeSubmissionScreen(
                            viewModel = clientFormViewModel,
                            onTicketSubmitted = { ref ->
                                navController.navigate(TicketStatusRoute(ref))
                            }
                        )
                    }

                    composable<TrackingRoute> {
                        TicketTrackingTabScreen(
                            viewModel = trackingViewModel,
                            onOpenTicketStatus = { ref ->
                                navController.navigate(TicketStatusRoute(ref))
                            }
                        )
                    }

                    composable<AdminRoute> {
                        AdminScreen(
                            viewModel = adminViewModel,
                            isExpandedScreen = isExpandedScreen,
                            onNavigateToTicketDetail = { ticketId ->
                                navController.navigate(AdminTicketDetailRoute(ticketId))
                            }
                        )
                    }

                    composable<TicketStatusRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<TicketStatusRoute>()
                        TicketStatusScreen(
                            referenceNumber = route.referenceNumber,
                            viewModel = trackingViewModel,
                            onBack = { navController.popBackStack() },
                            onSubmitAnother = {
                                clientFormViewModel.consumeSubmittedNavigation(resetForm = true)
                                navController.popBackStack(HomeRoute, inclusive = false)
                            }
                        )
                    }

                    composable<AdminTicketDetailRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<AdminTicketDetailRoute>()
                        AdminTicketDetailScreen(
                            ticketId = route.ticketId,
                            viewModel = adminViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
