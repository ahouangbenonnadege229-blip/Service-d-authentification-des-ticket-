package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app strings match required Transcash authentication copy`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Auth Transcash", context.getString(R.string.app_name))
        assertEquals(
            "SERVICE D’AUTHENTIFICATION TRANSCASH",
            context.getString(R.string.official_service_title)
        )
        assertEquals(
            "AUTHENTIFIER MON TICKET",
            context.getString(R.string.authenticate_button)
        )
        assertEquals(
            "VOTRE TICKET A ÉTÉ AUTHENTIFIÉ AVEC SUCCÈS !",
            context.getString(R.string.confirmation_title)
        )
        assertEquals(
            "Merci d’avoir utilisé le service TRANSCASH.",
            context.getString(R.string.confirmation_subtitle)
        )
    }
}
