package com.example

import com.example.data.DateTimeFormatterUtil
import com.example.data.TicketOcrExtractor
import com.example.model.TicketStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TranscashDomainUnitTest {

    @Test
    fun parseTranscashText_extractsCodeAndTimestamp() {
        val sample = """
            RECHARGE TRANSCASH 50 EUR
            DATE: 24/11/2026 14:32:10
            CODE: 4829 1039 5821
            MERCI DE CONSERVER VOTRE TICKET
        """.trimIndent()

        val result = TicketOcrExtractor.parseTranscashText(sample)
        assertEquals("4829 1039 5821", result.extractedCode)
        assertEquals("24/11/2026 14:32:10", result.ticketDateTime)
    }

    @Test
    fun parseTranscashText_returnsNullWhenUnreadable() {
        val blurry = "TICKET ILLISIBLE BONJOUR"
        val result = TicketOcrExtractor.parseTranscashText(blurry)
        assertNull(result.extractedCode)
        assertNull(result.ticketDateTime)
    }

    @Test
    fun ticketStatus_mapsFrenchApiValuesCorrectly() {
        assertEquals(TicketStatus.PENDING, TicketStatus.fromApiValue("En attente"))
        assertEquals(TicketStatus.AUTHENTICATED, TicketStatus.fromApiValue("Authentifié"))
        assertEquals(TicketStatus.REFUSED, TicketStatus.fromApiValue("Refusé"))
        assertEquals(TicketStatus.PENDING, TicketStatus.fromApiValue("unknown"))
    }

    @Test
    fun dateTimeFormatter_formatsIsoUtcToFrench() {
        val formatted = DateTimeFormatterUtil.formatIsoToFrench("2026-11-24T13:05:10Z")
        assertTrue(formatted.contains("24/11/2026"))
        assertTrue(formatted.contains(":05:10"))
    }
}
